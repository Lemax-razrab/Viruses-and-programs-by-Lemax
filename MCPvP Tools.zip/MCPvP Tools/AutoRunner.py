import threading
import tkinter as tk
from pynput.keyboard import Controller
import time

keyboard = Controller()

class WKeyController:
    def __init__(self):
        self.is_pressed = False
        self.thread = None
        self.lock = threading.Lock()

    def press_w(self):
        with self.lock:
            if not self.is_pressed:
                keyboard.press('w')
                self.is_pressed = True

    def release_w(self):
        with self.lock:
            if self.is_pressed:
                keyboard.release('w')
                self.is_pressed = False

w_controller = WKeyController()

def start_pressing():
    w_controller.press_w()

def stop_pressing():
    w_controller.release_w()

root = tk.Tk()
root.title("Auto Runner")

start_button = tk.Button(root, text="Start", command=start_pressing)
start_button.pack(pady=10)

stop_button = tk.Button(root, text="Stop", command=stop_pressing)
stop_button.pack(pady=10)

root.mainloop()